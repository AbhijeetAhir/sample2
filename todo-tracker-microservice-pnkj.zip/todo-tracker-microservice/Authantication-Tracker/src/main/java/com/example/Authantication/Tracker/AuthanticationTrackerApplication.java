package com.example.Authantication.Tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthanticationTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthanticationTrackerApplication.class, args);
	}

}
