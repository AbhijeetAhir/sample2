package com.example.Authantication.Tracker.controller;

import com.example.Authantication.Tracker.domain.User;
import com.example.Authantication.Tracker.exception.UserAlreadyExistException;
import com.example.Authantication.Tracker.exception.UserNotFoundException;
import com.example.Authantication.Tracker.service.TokenGenerator;
import com.example.Authantication.Tracker.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
@RestController
@RequestMapping("/user-app-v1")
public class UserController {

    UserService userService;
    TokenGenerator tokenGenerator;

    @Autowired
    public UserController(UserService userService, TokenGenerator tokenGenerator) {
        this.userService = userService;
        this.tokenGenerator = tokenGenerator;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) throws UserAlreadyExistException {
        return new ResponseEntity<>(userService.saveUser(user), HttpStatus.ACCEPTED);
    }

    @PostMapping("/log-in")
    public ResponseEntity<?> login(@RequestBody User user) throws UserNotFoundException {

        User result=userService.login(user.getEmail(),user.getPassword());
        if (result!=null){

            Map<String,String> map= tokenGenerator.generateToken(result);
            return new ResponseEntity<>(map,HttpStatus.OK);
        }else {
            return new ResponseEntity<>("Invalid User or User Does Not Exist",HttpStatus.NOT_FOUND);
        }

    }

    @PutMapping("/updatePassword/{email}")
    public ResponseEntity<?> updatePassword(@PathVariable String email, @RequestBody User user) throws UserNotFoundException {
        return  new ResponseEntity<>(userService.changePassword(email,user),HttpStatus.OK);
    }



}

