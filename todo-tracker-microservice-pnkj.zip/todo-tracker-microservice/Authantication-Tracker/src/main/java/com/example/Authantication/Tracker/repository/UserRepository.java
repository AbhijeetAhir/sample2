package com.example.Authantication.Tracker.repository;

import com.example.Authantication.Tracker.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,String> {
}
