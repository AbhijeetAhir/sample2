package com.example.Authantication.Tracker.service;

import com.example.Authantication.Tracker.domain.User;
import com.example.Authantication.Tracker.exception.UserAlreadyExistException;
import com.example.Authantication.Tracker.exception.UserNotFoundException;

public interface UserService {
    public User saveUser(User user) throws UserAlreadyExistException;
    public User login (String email , String password) throws UserNotFoundException;
    public User changePassword(String email,User user) throws UserNotFoundException;
}
