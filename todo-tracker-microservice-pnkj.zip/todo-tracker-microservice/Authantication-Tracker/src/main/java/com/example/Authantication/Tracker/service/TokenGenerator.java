package com.example.Authantication.Tracker.service;

import com.example.Authantication.Tracker.domain.User;

import java.util.Map;

public interface TokenGenerator {

    public Map<String,String> generateToken(User user);
}
