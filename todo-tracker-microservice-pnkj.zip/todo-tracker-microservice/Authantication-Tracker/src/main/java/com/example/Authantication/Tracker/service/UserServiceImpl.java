package com.example.Authantication.Tracker.service;

import com.example.Authantication.Tracker.domain.User;
import com.example.Authantication.Tracker.exception.UserAlreadyExistException;
import com.example.Authantication.Tracker.exception.UserNotFoundException;
import com.example.Authantication.Tracker.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{

    private UserRepository userRepository;
    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User user) throws UserAlreadyExistException {
        if (userRepository.findById(user.getEmail()).isPresent()){

            throw new UserAlreadyExistException();
        }
        //User user =
        return userRepository.save(user);
    }

    @Override
    public User login(String email , String password) throws UserNotFoundException {

        if(userRepository.findById(email).isPresent()){
            User user= userRepository.findById(email).get();
            if (user.getPassword().equals(password)){
                return user;
            }
            throw new UserNotFoundException();
        }
        return null;
    }

    @Override
    public User changePassword(String email , User user) throws UserNotFoundException {

        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User user1= userRepository.findById(email).get();
        user1.setPassword(user.getPassword());
        userRepository.save(user);
        return user;
    }
}
