package com.example.Authantication.Tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthanticationTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
