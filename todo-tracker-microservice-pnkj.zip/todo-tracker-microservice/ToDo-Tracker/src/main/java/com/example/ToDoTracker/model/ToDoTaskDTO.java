package com.example.ToDoTracker.model;

public class ToDoTaskDTO {
}
