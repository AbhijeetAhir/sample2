package com.example.ToDoTracker.proxy;

import com.example.ToDoTracker.model.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "UserAuthService-ToDo",url = "localhost:1111")
public interface UserProxy {
    @PostMapping("/user/app/register")
    ResponseEntity<?> registerUser(@RequestBody User user);
}

