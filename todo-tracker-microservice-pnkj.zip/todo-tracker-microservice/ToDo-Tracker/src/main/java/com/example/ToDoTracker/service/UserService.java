package com.example.ToDoTracker.service;

import com.example.ToDoTracker.model.User;

public interface UserService {
    public User registerUser(User user);

}
