package com.example.ToDoTracker.repository;


import com.example.ToDoTracker.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserRepository extends MongoRepository<User,String> {
}
