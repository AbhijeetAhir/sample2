package com.example.ToDoTracker.service;

import com.example.ToDoTracker.model.Task;
import com.example.ToDoTracker.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class UserTaskServiceImpl implements UserTaskService{

    @Autowired
    TaskRepository taskRepository;

    @Override
    public Task addTask(String emailId, Task task) {
        task.setEmailId(emailId);
        return taskRepository.save(task);
    }

//    @Override
//    public boolean deleteTask(Task task) {
//        boolean removeStatus=false;
//        if(taskRepository.existsById(task.getTaskId())){
//            taskRepository.deleteById(task.getTaskId());
//            removeStatus=true;
//        }
//        return removeStatus;
//    }

    @Override
    public boolean deleteTask(int taskId) {
        boolean removeStatus=false;
        if(taskRepository.existsById(taskId)){
            taskRepository.deleteById(taskId);
            removeStatus=true;
        }
        return removeStatus;
    }


    @Override
    public List<Task> getAllToDoTasks(String emailId) {
        List<Task> allTasks=taskRepository.findAll();
        List<Task> allToDoTasks=new ArrayList<>();
        Iterator itr=allTasks.iterator();
        while(itr.hasNext()){
            Task currentTask=(Task) itr.next();
            if(currentTask.getStatus().equalsIgnoreCase("TODO") && currentTask.getEmailId().equalsIgnoreCase(emailId)){
                allToDoTasks.add(currentTask);
            }
        }
        List<Task> sortedTasks=new ArrayList<>();
        Iterator itr2= allToDoTasks.iterator();
        //Sorting tasks as per their priority levels.. HIGH NORMAL LOW
        while(itr2.hasNext()){
            Task currentTask=(Task) itr2.next();
            if(currentTask.getPriority().equalsIgnoreCase("HIGH")){
                sortedTasks.add(currentTask);
            }
        }
        Iterator itr3= allToDoTasks.iterator();
        while(itr3.hasNext()){
            Task currentTask=(Task) itr3.next();
            if(currentTask.getPriority().equalsIgnoreCase("NORMAL")){
                sortedTasks.add(currentTask);
            }
        }
        Iterator itr4= allToDoTasks.iterator();
        while(itr4.hasNext()){
            Task currentTask=(Task) itr4.next();
            if(currentTask.getPriority().equalsIgnoreCase("LOW")){
                sortedTasks.add(currentTask);
            }
        }
        return sortedTasks;
    }

    @Override
    public List<Task> getAllArchievedTasks(String emailId) {
        List<Task> allTasks=taskRepository.findAll();
        List<Task> allArchievedTasks=new ArrayList<>();
        Iterator itr=allTasks.iterator();
        while(itr.hasNext()){
            Task currentTask=(Task) itr.next();
            if(currentTask.getStatus().equalsIgnoreCase("ARCHIEVED")){
                allArchievedTasks.add(currentTask);
            }
        }
        return allArchievedTasks;
    }

    @Override
    public List<Task> getAllCompletedTasks(String emailId) {
        List<Task> allTasks=taskRepository.findAll();
        List<Task> allCompletedTasks=new ArrayList<>();
        Iterator itr=allTasks.iterator();
        while(itr.hasNext()){
            Task currentTask=(Task) itr.next();
            if(currentTask.getStatus().equalsIgnoreCase("Todo")){
                allCompletedTasks.add(currentTask);
            }
        }
        return allCompletedTasks;
    }

    @Override
    public Task CompletedTask(int taskId) {
        Task currentTask=taskRepository.findById(taskId).get();
        currentTask.setStatus("COMPLETED");
        return taskRepository.save(currentTask);
    }

    @Override
    public Task addToArchieveTask(int taskId) {
        Task currentTask=taskRepository.findById(taskId).get();
        currentTask.setStatus("ARCHIEVED");
        return taskRepository.save(currentTask);
    }

    @Override
    public Task restoreArchieveTask(int taskId) {
        Task currentTask=taskRepository.findById(taskId).get();
        currentTask.setStatus("TODO");
        return taskRepository.save(currentTask);
    }
}
