package com.example.ToDoTracker.service;

import com.example.ToDoTracker.model.User;
import com.example.ToDoTracker.proxy.UserProxy;
import com.example.ToDoTracker.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserProxy userProxy;

    @Override
    public User registerUser(User user) {
        User sendUserDetails = new User();
//          EmailData emailData = new EmailData();
//        emailData.setReceiver(user.getEmail());
//        emailData.setSubject("You have sign up successfully");
//        emailData.setMessage("Welcome to AAAPAR - the ToDo Tracker App ...");
//        try {
//            mailProxy.sendEmail(emailData);
//            return user;
//        } catch (Exception e) {
//            System.out.println(e);
//        }
        sendUserDetails.setEmail(user.getEmail());
        sendUserDetails.setPassword(user.getPassword());
        userProxy.registerUser(sendUserDetails);
        return userRepository.save(user);
    }

}
