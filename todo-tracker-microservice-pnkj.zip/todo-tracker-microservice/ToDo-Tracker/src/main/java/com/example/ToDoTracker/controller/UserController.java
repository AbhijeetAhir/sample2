package com.example.ToDoTracker.controller;

import com.example.ToDoTracker.exception.UserAlreadyExistsException;
import com.example.ToDoTracker.model.User;

import com.example.ToDoTracker.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/todo-app-v1")
//@CrossOrigin
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/auth/register")
    public ResponseEntity<?> addUser(@RequestBody User user ){
        return new ResponseEntity<>(userService.registerUser(user), HttpStatus.CREATED);
    }

}
//    @Autowired
//    UserService userService;
//
//      //http://localhost:65002/todo-app/auth/register
//    @PostMapping("/auth/register")
//    public ResponseEntity<?> addUser(@RequestBody User user )throws UserAlreadyExistsException {
////        System.out.println("registr method");
//        ResponseEntity responseEntity=null;
//        try {
//            responseEntity=new ResponseEntity<>(userService.registerUser(user), HttpStatus.CREATED);
//        }catch (UserAlreadyExistsException e){
//            throw new UserAlreadyExistsException();
//        }catch (Exception e){
//            responseEntity=new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//        return responseEntity;
//    }