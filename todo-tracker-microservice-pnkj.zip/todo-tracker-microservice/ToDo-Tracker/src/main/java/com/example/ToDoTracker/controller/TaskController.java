package com.example.ToDoTracker.controller;

import com.example.ToDoTracker.model.Task;
import com.example.ToDoTracker.service.UserService;
import com.example.ToDoTracker.service.UserTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/todo-app-v1")
public class TaskController {

    @Autowired
    UserTaskService userTaskService;

    @PostMapping("/add-task")
    public ResponseEntity<?> addTask(HttpServletRequest request, @RequestBody Task task){
        String current_email = (String) request.getAttribute("userEmail");
        System.out.println(current_email);
        return new ResponseEntity<>(userTaskService.addTask(current_email, task),HttpStatus.OK);
    }

//    @PostMapping("/remove-task")
//    public ResponseEntity<?> removeTask(HttpServletRequest request, @RequestBody Task task){
//        return new ResponseEntity<>(userTaskService.deleteTask(task),HttpStatus.OK);
//    }

    @PostMapping("/remove-task/{taskId}")
    public ResponseEntity<?> removeTask(HttpServletRequest request, @PathVariable int taskId){
        return new ResponseEntity<>(userTaskService.deleteTask(taskId),HttpStatus.OK);
    }

    @PostMapping("/add-task-to-archieve/{taskId}")
    public ResponseEntity<?> addTaskToArchieve(HttpServletRequest request, @PathVariable int taskId){
        return new ResponseEntity<>(userTaskService.addToArchieveTask(taskId),HttpStatus.OK);
    }

    @PostMapping("/remove-task-from-archieve/{taskId}")
    public ResponseEntity<?> removeTaskFromArchieve(HttpServletRequest request, @PathVariable int taskId){
        return new ResponseEntity<>(userTaskService.restoreArchieveTask(taskId),HttpStatus.OK);
    }

    //task--- delete
    //todo- archieve, completed
    //archieve- restore

    @GetMapping("/get-all-todo-tasks")
    public ResponseEntity<?> getAllToDoTasks(HttpServletRequest request){
        String current_email = (String) request.getAttribute("userEmail");
        System.out.println(current_email);
        return new ResponseEntity<>(userTaskService.getAllToDoTasks(current_email),HttpStatus.OK);
    }

    @PostMapping("add-to-archieve/{taskId}")
    public ResponseEntity<?> addToArchieve(HttpServletRequest request, @PathVariable int taskId){
        return new ResponseEntity<>(userTaskService.addToArchieveTask(taskId),HttpStatus.OK);
    }

    @PostMapping("restore-archieve/{taskId}")
    public ResponseEntity<?> restoreArchieve(HttpServletRequest request, @PathVariable int taskId){
        return new ResponseEntity<>(userTaskService.restoreArchieveTask(taskId),HttpStatus.OK);
    }

    @PostMapping("completed-task/{taskId}")
    public ResponseEntity<?> completedTask(HttpServletRequest request, @PathVariable int taskId){
        return new ResponseEntity<>(userTaskService.CompletedTask(taskId),HttpStatus.OK);
    }

}