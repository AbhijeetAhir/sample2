package com.example.ToDoTracker.service;

import com.example.ToDoTracker.model.Task;

import java.util.List;

public interface UserTaskService {

    public abstract Task addTask(String emailId, Task task);
    //public abstract boolean deleteTask(Task task);
    public abstract boolean deleteTask(int taskId);
    public abstract Task addToArchieveTask(int taskId);
    public abstract Task restoreArchieveTask(int taskId);
    public abstract Task CompletedTask(int taskId);
    public abstract List<Task> getAllToDoTasks(String emailId);
    public abstract List<Task> getAllArchievedTasks(String emailId);
    public abstract List<Task> getAllCompletedTasks(String emailId);
}
