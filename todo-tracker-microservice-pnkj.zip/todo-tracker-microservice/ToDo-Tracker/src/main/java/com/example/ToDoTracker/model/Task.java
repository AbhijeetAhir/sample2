package com.example.ToDoTracker.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document
public class Task {
    @Id
    private int taskId;
    private String emailId;
    private String status;//continue, archieved, completed
    private String priority; //low, normal, high
    private String todoTitle; //Heading
    private String todoDescription; //task body
    private String category; //sports, dance,etc
    private String createdDate;
    private String dueDate;
    private String color;
}

/*
user.... mongo user

todotask... mongo task,  remove
completed task
archieved task add
 */
