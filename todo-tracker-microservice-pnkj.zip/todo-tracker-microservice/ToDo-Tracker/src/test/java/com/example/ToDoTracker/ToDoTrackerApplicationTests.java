package com.example.ToDoTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToDoTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
